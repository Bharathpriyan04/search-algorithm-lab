# Ex. No. 5 — To Find Min-Max Value by Applying Divide and Conquer Technique

**CS5303 – Design and Analysis of Algorithms Lab**
**Chennai Institute of Technology | Dept. of CSE**

| | |
|---|---|
| **Name** | *<your name here>* |
| **Register No.** | *<your register number>* |
| **Date** | *<date of submission>* |

---

## Aim

To find the minimum and maximum element in a given array of `n` elements
by applying the Divide and Conquer technique, and to compare the number
of comparisons required against the naive (linear scan) method and the
theoretical formula `3n/2 - 2`.

## Algorithm

```
MIN_MAX_DC(arr, low, high)
1. If low == high:
       return arr[low], arr[low]              // single element
2. If high == low + 1:
       compare arr[low] and arr[high]          // two elements, 1 comparison
       return the smaller as min, larger as max
3. Else:
       mid = (low + high) / 2
       (lmin, lmax) = MIN_MAX_DC(arr, low, mid)        // divide - left half
       (rmin, rmax) = MIN_MAX_DC(arr, mid + 1, high)   // divide - right half
       overall_min = min(lmin, rmin)           // conquer, 1 comparison
       overall_max = max(lmax, rmax)           // conquer, 1 comparison
       return overall_min, overall_max
```

**Recurrence relation:** T(n) = 2T(n/2) + 2, giving approximately `3n/2 - 2`
comparisons in the best/average/worst case — fewer than the naive method's
`2n - 2` comparisons.

## Program

The full working code is split across these files (see repo):

- `min_max.py` — core algorithm (`min_max_dc`, `min_max_naive`), takes the
  array from **user input** at the keyboard.
- `app.py` — optional Flask web interface for the same algorithm.
- `templates/index.html` — web form used by `app.py`.

### Running the command-line version

```bash
python min_max.py
```
```
Enter the numbers separated by spaces or commas: 3, 1, 7, 4, 9, 2, 8, 5, 6, 0
```

### Running the web version

```bash
pip install -r requirements.txt
python app.py
```
Then open `http://localhost:5000` and enter the numbers in the form.

## Sample Output

```
Array              : [3, 1, 7, 4, 9, 2, 8, 5, 6, 0]
Min                : 0
Max                : 9
D&C Comparisons    : 14
Naive Comparisons  : 18
Formula (3n/2 - 2) : 13
```

## Performance Analysis

| n (Size) | D&C Comparisons | Naive Comparisons | Formula 3n/2 - 2 |
|---|---|---|---|
| 10    | ~13–14 | ~18   | 13   |
| 100   | ~148   | ~198  | 148  |
| 1000  | ~1498  | ~1998 | 1498 |
| 10000 | ~14998 | ~19998| 14998|

*(Exact D&C counts vary slightly by input arrangement; naive count is
always `2n - 2` for `n ≥ 1`.)*

## Result

Thus, the minimum and maximum of a given array were found using the
Divide and Conquer technique, and it was verified that the number of
comparisons closely matches the theoretical bound of `3n/2 - 2`, which
is fewer than the `2n - 2` comparisons required by the naive method.

---

## Deployment

This program is also deployed as a small web app.

- **Live demo:** *<add your Render URL here after deploying>*
- **Deploy your own copy:** see [Render](https://render.com) → New Web
  Service → connect this repo → it auto-detects `render.yaml`.

## Files in this repo

| File | Purpose |
|---|---|
| `min_max.py` | Core algorithm + CLI (user input) |
| `app.py` | Flask web app |
| `templates/index.html` | Web form UI |
| `requirements.txt` | Python dependencies |
| `render.yaml` | Render deployment config |
| `.gitignore` | Ignore caches/venvs in git |
